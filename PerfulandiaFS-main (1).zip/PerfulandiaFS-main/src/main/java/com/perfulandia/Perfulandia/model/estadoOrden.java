
package com.perfulandia.Perfulandia.model;

public enum estadoOrden {
    PENDIENTE,
    PROCESANDO,
    ENVIADO,
    ENTREGADO,
    CANCELADO
}
