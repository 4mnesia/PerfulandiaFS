package com.perfulandia.Perfulandia.model;

public enum RolUsuario {
    CLIENTE,
    ADMINISTRADOR
}
