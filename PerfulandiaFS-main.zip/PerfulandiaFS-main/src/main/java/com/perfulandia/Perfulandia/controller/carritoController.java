package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.carrito;
import com.perfulandia.Perfulandia.service.carritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carrito")
public class carritoController {

    @Autowired
    private carritoService carritoService;

    @GetMapping("/{id}")
    public carrito getCarritoById(@PathVariable Long id) {
        return carritoService.getCarritoById(id);
    }

    @PostMapping
    public carrito saveCarrito(@RequestBody carrito carrito) {
        return carritoService.saveCarrito(carrito);
    }

    @DeleteMapping("/{id}")
    public void deleteCarritoById(@PathVariable Long id) {
        carritoService.deleteCarritoById(id);
    }

    @GetMapping("/usuario/{usuarioId}")
    public carrito getCarritoByUsuarioId(@PathVariable Long usuarioId) {
        return carritoService.getCarritoByUsuarioId(usuarioId);
    }

    @DeleteMapping("/usuario/{usuarioId}")
    public void deleteCarritoByUsuarioId(@PathVariable Long usuarioId) {
        carritoService.deleteCarritoByUsuarioId(usuarioId);
    }

    @PutMapping("/{carritoId}/usuario/{usuarioId}")
    public void updateCarrito(@PathVariable Long carritoId, @PathVariable Long usuarioId) {
        carritoService.updateCarrito(carritoId, usuarioId);
    }

    @GetMapping("/{carritoId}/total")
    public Integer calcularTotal(@PathVariable Long carritoId) {
        return carritoService.calcularTotal(carritoId);
    }

    @DeleteMapping("/{carritoId}/vaciar")
    public void vaciarCarrito(@PathVariable Long carritoId) {
        carritoService.vaciarCarrito(carritoId);
    }
}
