package com.perfulandia.Perfulandia.service;

import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.perfulandia.Perfulandia.model.itemCarrito;
import com.perfulandia.Perfulandia.model.orden;
import com.perfulandia.Perfulandia.repository.itemCarritoRepository;

@Service
public class ordenService {

    @Autowired
    private itemCarritoRepository itemCarritoRepository;

    public List<itemCarrito> getAllItems() {
        return itemCarritoRepository.findAll();
    }

    public itemCarrito getItemCarritoById(Long id) {
        return itemCarritoRepository.findById(id).orElse(null);
    }

    public itemCarrito saveItemCarrito(itemCarrito itemCarrito) {
        return itemCarritoRepository.save(itemCarrito);
    }

    public orden getOrdenById(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getOrdenById'");
    }

    public orden saveOrden(orden orden) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveOrden'");
    }

    public void deleteOrdenById(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteOrdenById'");
    }

    public List<orden> getOrdenesByUsuarioId(Long usuarioId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getOrdenesByUsuarioId'");
    }

    public void updateEstadoOrden(Long ordenId, Long estadoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateEstadoOrden'");
    }

    public List<orden> getOrdenesByUsuarioIdAndEstadoId(Long usuarioId, Long estadoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getOrdenesByUsuarioIdAndEstadoId'");
    }
}
