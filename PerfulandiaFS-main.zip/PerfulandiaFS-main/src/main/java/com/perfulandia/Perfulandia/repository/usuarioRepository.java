package com.perfulandia.Perfulandia.repository;

import jakarta.transaction.Transactional;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.perfulandia.Perfulandia.model.usuario;

@Repository
public interface usuarioRepository extends JpaRepository<usuario, Long> {
    
    // leer
    @SuppressWarnings("null")
    Optional<usuario> findById(Long id);
    @SuppressWarnings("null")
    List<usuario> findAll();

    // leer por email
    Optional<usuario> findByEmail(String email);
    Boolean existsByEmail(String email);

    // leer administrador
    @Query("SELECT u FROM usuario u WHERE u.rol = 'ADMINISTRADOR'")
    List<usuario> findAllAdministradores();

    // leer cliente
    @Query("SELECT u FROM usuario u WHERE u.rol = 'CLIENTE'")
    List<usuario> findAllClientes();

    // actualizar
    @Transactional
    @Modifying
    @Query("UPDATE usuario u SET u.nombre = :nombre, u.email = :email WHERE u.id = :id")
    void actualizarUsuario(@Param("id") Long id,
                           @Param("nombre") String nombre,
                           @Param("email") String email);

    // actualizar password
    @Transactional
    @Modifying
    @Query("UPDATE usuario u SET u.password = :password WHERE u.id = :id")
    void actualizarPassword(@Param("id") Long id,
                            @Param("password") String password);

    // eliminar
    @SuppressWarnings("null")
    void deleteById(Long id); // Heredado

    @Transactional
    @Modifying
    @Query("DELETE FROM usuario u WHERE u.email = :email")
    void deleteByEmail(@Param("email") String email);
}
