package com.perfulandia.Perfulandia.service;

import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.perfulandia.Perfulandia.model.itemCarrito;
import com.perfulandia.Perfulandia.repository.itemCarritoRepository;

@Service
public class itemCarritoService {

    @Autowired
    private itemCarritoRepository itemCarritoRepository;

    /**
     * Obtiene todos los items del carrito
     * 
     * @return Lista de itemCarrito
     */
    public List<itemCarrito> getAllItems() {
        return itemCarritoRepository.findAll();
    }

    /**
     * Busca un itemCarrito por su ID
     * 
     * @param id ID del itemCarrito
     * @return itemCarrito si existe, null si no
     */
    public itemCarrito getItemCarritoById(Long id) {
        return itemCarritoRepository.findById(id).orElse(null);
    }

    /**
     * Guarda un itemCarrito
     * 
     * @param itemCarrito objeto a guardar
     * @return itemCarrito guardado
     */
    public itemCarrito saveItemCarrito(itemCarrito itemCarrito) {
        return itemCarritoRepository.save(itemCarrito);
    }

    public void vaciarItems(Long carritoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'vaciarItems'");
    }

    public Integer calcularTotal(Long carritoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularTotal'");
    }

    public void updateItemCarrito(Long itemId, Integer cantidad, Double precio) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateItemCarrito'");
    }

    public void deleteItemsByCarritoId(Long carritoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteItemsByCarritoId'");
    }

    public List<itemCarrito> getItemsByCarritoId(Long carritoId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getItemsByCarritoId'");
    }

    /*
    public detalleOrden getDetalleOrdenById(Long id) {
        return detalleOrdenRepository.findById(id).orElse(null);
    }
    */
}
