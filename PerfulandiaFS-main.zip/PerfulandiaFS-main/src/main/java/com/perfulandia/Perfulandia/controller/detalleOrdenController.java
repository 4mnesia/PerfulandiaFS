package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.detalleOrden;
import com.perfulandia.Perfulandia.service.detalleOrdenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/detalles-orden")
public class detalleOrdenController {

    @Autowired
    private detalleOrdenService detalleOrdenService;

    @GetMapping("/{id}")
    public detalleOrden getDetalleOrdenById(@PathVariable Long id) {
        return detalleOrdenService.getDetalleOrdenById(id);
    }

    @PostMapping
    public detalleOrden saveDetalleOrden(@RequestBody detalleOrden detalleOrden) {
        return detalleOrdenService.saveDetalleOrden(detalleOrden);
    }

    @DeleteMapping("/{id}")
    public void deleteDetalleOrdenById(@PathVariable Long id) {
        detalleOrdenService.deleteDetalleOrdenById(id);
    }

    @GetMapping("/orden/{ordenId}")
    public List<detalleOrden> getDetalleOrdenByOrdenId(@PathVariable Long ordenId) {
        return detalleOrdenService.getDetalleOrdenByOrdenId(ordenId);
    }

    @DeleteMapping("/orden/{ordenId}")
    public void deleteDetalleOrdenByOrdenId(@PathVariable Long ordenId) {
        detalleOrdenService.deleteDetalleOrdenByOrdenId(ordenId);
    }

    @PutMapping("/{detalleOrdenId}")
    public void updateDetalleOrden(
            @PathVariable Long detalleOrdenId,
            @RequestParam Integer cantidad,
            @RequestParam Double precio
    ) {
        detalleOrdenService.updateDetalleOrden(detalleOrdenId, cantidad, precio);
    }

    @GetMapping("/orden/{ordenId}/total")
    public Integer calcularTotal(@PathVariable Long ordenId) {
        return detalleOrdenService.calcularTotal(ordenId);
    }

    @DeleteMapping("/orden/{ordenId}/vaciar")
    public void vaciarDetalle(@PathVariable Long ordenId) {
        detalleOrdenService.vaciarDetalle(ordenId);
    }
}
