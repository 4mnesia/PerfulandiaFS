package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.producto;
import com.perfulandia.Perfulandia.service.productoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
public class productoController {

    @Autowired
    private productoService productoService;

    @GetMapping("/{id}")
    public producto getProductoById(@PathVariable Long id) {
        return productoService.getProductoById(id);
    }

    @PostMapping
    public producto saveProducto(@RequestBody producto producto) {
        return productoService.saveProducto(producto);
    }

    @DeleteMapping("/{id}")
    public void deleteProductoById(@PathVariable Long id) {
        productoService.deleteProducto(id);
    }

    @GetMapping
    public List<producto> getAllProductos() {
        return productoService.getAllProductos();
    }

    @PutMapping("/{id}")
    public void updateProducto(@PathVariable Long id, @RequestBody producto producto) {
        productoService.updateProducto(id, producto);
    }

    @GetMapping("/categoria/{categoria}")
    public List<producto> getProductosByCategoria(@PathVariable String categoria) {
        return productoService.getProductosByCategoria(categoria);
    }

    @GetMapping("/nombre/{nombre}")
    public producto getProductosByNombre(@PathVariable String nombre) {
        return productoService.getProductoById(nombre);
    }

    @GetMapping("/stock/{stock}")
    public List<producto> getProductosByStockGreaterThan(@PathVariable Integer stock) {
        return productoService.getProductosByStockGreaterThan(stock);
    }
}
