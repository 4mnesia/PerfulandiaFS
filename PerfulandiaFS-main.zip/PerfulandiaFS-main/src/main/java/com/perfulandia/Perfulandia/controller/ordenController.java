package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.orden;
import com.perfulandia.Perfulandia.service.ordenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ordenes")
public class ordenController {

    @Autowired
    private ordenService ordenService;

    @GetMapping("/{id}")
    public orden getOrdenById(@PathVariable Long id) {
        return ordenService.getOrdenById(id);
    }

    @PostMapping
    public orden saveOrden(@RequestBody orden orden) {
        return ordenService.saveOrden(orden);
    }

    @DeleteMapping("/{id}")
    public void deleteOrdenById(@PathVariable Long id) {
        ordenService.deleteOrdenById(id);
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<orden> getOrdenesByUsuarioId(@PathVariable Long usuarioId) {
        return ordenService.getOrdenesByUsuarioId(usuarioId);
    }

    @DeleteMapping("/usuario/{usuarioId}")
    public void deleteOrdenesByUsuarioId(@PathVariable Long usuarioId) {
        ordenService.deleteOrdenById(usuarioId);
    }

    @PutMapping("/{ordenId}/estado/{estadoId}")
    public void updateEstadoOrden(@PathVariable Long ordenId, @PathVariable Long estadoId) {
        ordenService.updateEstadoOrden(ordenId, estadoId);
    }

    @GetMapping("/usuario/{usuarioId}/estado/{estadoId}")
    public List<orden> getOrdenesByUsuarioIdAndEstadoId(@PathVariable Long usuarioId, @PathVariable Long estadoId) {
        return ordenService.getOrdenesByUsuarioIdAndEstadoId(usuarioId, estadoId);
    }
}
