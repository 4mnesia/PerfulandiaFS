package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.itemCarrito;
import com.perfulandia.Perfulandia.service.itemCarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/items-carrito")
public class itemCarritoController {

    @Autowired
    private itemCarritoService itemCarritoService;

    @GetMapping("/{id}")
    public itemCarrito getItemCarritoById(@PathVariable Long id) {
        return itemCarritoService.getItemCarritoById(id);
    }

    @PostMapping
    public itemCarrito saveItemCarrito(@RequestBody itemCarrito itemCarrito) {
        return itemCarritoService.saveItemCarrito(itemCarrito);
    }

    @DeleteMapping("/{id}")
    public void deleteItemCarritoById(@PathVariable Long id) {
        itemCarritoService.getItemCarritoById(id);
    }

    @GetMapping("/carrito/{carritoId}")
    public List<itemCarrito> getItemsByCarritoId(@PathVariable Long carritoId) {
        return itemCarritoService.getItemsByCarritoId(carritoId);
    }

    @DeleteMapping("/carrito/{carritoId}")
    public void deleteItemsByCarritoId(@PathVariable Long carritoId) {
        itemCarritoService.deleteItemsByCarritoId(carritoId);
    }

    @PutMapping("/{itemId}")
    public void updateItemCarrito(
            @PathVariable Long itemId,
            @RequestParam Integer cantidad,
            @RequestParam Double precio
    ) {
        itemCarritoService.updateItemCarrito(itemId, cantidad, precio);
    }

    @GetMapping("/carrito/{carritoId}/total")
    public Integer calcularTotal(@PathVariable Long carritoId) {
        return itemCarritoService.calcularTotal(carritoId);
    }

    @DeleteMapping("/carrito/{carritoId}/vaciar")
    public void vaciarItems(@PathVariable Long carritoId) {
        itemCarritoService.vaciarItems(carritoId);
    }
}
