package com.perfulandia.Perfulandia.controller;

import com.perfulandia.Perfulandia.model.estadoOrden;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estados-orden")
public class estadoOrdenController<estadoOrdenService> {

    @Autowired
    private estadoOrdenService estadoOrdenService;

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @GetMapping
    public List<estadoOrden> getAllEstadosOrden() {
        return ((estadoOrdenController) estadoOrdenService).getAllEstadosOrden();
    }

    @SuppressWarnings("rawtypes")
    @GetMapping("/{id}")
    public estadoOrden getEstadoOrdenById(@PathVariable Long id) {
        return ((estadoOrdenController) estadoOrdenService).getEstadoOrdenById(id);
    }

    @SuppressWarnings("rawtypes")
    @PostMapping
    public estadoOrden saveEstadoOrden(@RequestBody estadoOrden estadoOrden) {
        return ((estadoOrdenController) estadoOrdenService).saveEstadoOrden(estadoOrden);
    }

    @SuppressWarnings("rawtypes")
    @DeleteMapping("/{id}")
    public void deleteEstadoOrdenById(@PathVariable Long id) {
        ((estadoOrdenController) estadoOrdenService).deleteEstadoOrdenById(id);
    }

    @SuppressWarnings("rawtypes")
    @PutMapping("/{id}")
    public void updateEstadoOrden(@PathVariable Long id, @RequestBody estadoOrden estadoOrden) {
        ((estadoOrdenController) estadoOrdenService).updateEstadoOrden(id, estadoOrden);
    }
}
