package com.perfulandia.Perfulandia.model;

public enum rolUsuario {
    CLIENTE,
    ADMINISTRADOR
}
